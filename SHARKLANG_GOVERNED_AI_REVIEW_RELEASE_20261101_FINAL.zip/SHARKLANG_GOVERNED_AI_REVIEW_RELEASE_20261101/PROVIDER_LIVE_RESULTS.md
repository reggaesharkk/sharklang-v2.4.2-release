# Live provider trial record

Updated 2026-10-31 from the user's Windows PowerShell screenshots and confirmation. API keys were entered at hidden prompts and are not included. Provider calls were live inference requests; the demo's purchase amount and cap are simulated policy inputs and do not move money.

| Provider | Configured default model | Result | Witness receipt | Captured details |
| --- | --- | --- | --- | --- |
| Gemini | `gemini-3.5-flash-lite` | Screenshot-confirmed: HTTP 200; `AUTHORIZED_LIVE`; answer returned. | `SEALED`; `idempotent_replay: false`. | 41 prompt tokens, 30 completion tokens, 71 total. The response did not report monetary cost; check Google AI Studio usage for billing details. |
| Together AI | `Prism-ML/Ternary-Bonsai-27B` | Screenshot-confirmed: HTTP 200; `AUTHORIZED_LIVE`; answer returned using `https://api.together.ai/v1/chat/completions`. | `SEALED`; `idempotent_replay: false`. | 50 prompt tokens, 370 completion tokens, 420 total. Together lists this model as free serverless at the time of this record. |
| OpenRouter | `openrouter/free` | User-confirmed live request succeeded. | Reported successful by the demo; detailed receipt fields were not captured for this archive. | Exact response, usage, and cost were not captured. |
| Groq | `openai/gpt-oss-20b` | User-confirmed live request succeeded. | Reported successful by the demo; detailed receipt fields were not captured for this archive. | Exact response, usage, and cost were not captured. |

Earlier Together and Groq attempts returned HTTP 403 / Cloudflare error 1010. They preceded the updated Together API host and explicit SharkLang User-Agent; later calls succeeded. These results document provider inference only, not payment processing. The demo does not execute purchases or transfer funds.

