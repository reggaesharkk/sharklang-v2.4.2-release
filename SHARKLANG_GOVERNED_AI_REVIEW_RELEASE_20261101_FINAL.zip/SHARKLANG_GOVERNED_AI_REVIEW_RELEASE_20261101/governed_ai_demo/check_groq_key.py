#!/usr/bin/env python3
"""Check Groq API-key/model-list access without making a chat completion."""

from __future__ import annotations

import getpass
import json
import re
import sys
import urllib.error
import urllib.request


MODEL_ID = "openai/gpt-oss-20b"
MODELS_URL = "https://api.groq.com/openai/v1/models"


def _safe_provider_error(exc: urllib.error.HTTPError, key: str) -> str:
    detail = ""
    try:
        raw = exc.read(4096).decode("utf-8", errors="replace")
        payload = json.loads(raw)
        error = payload.get("error") if isinstance(payload, dict) else None
        if isinstance(error, dict):
            values = [error.get("code"), error.get("type"), error.get("message")]
            detail = " | ".join(str(value) for value in values if isinstance(value, str) and value)
        if not detail:
            detail = json.dumps(payload, ensure_ascii=True)
    except json.JSONDecodeError:
        detail = raw
    except (OSError, UnicodeError):
        detail = "Provider did not return a readable error body."
    if key:
        detail = detail.replace(key, "[REDACTED]")
    detail = re.sub(r"(?i)\bgsk_[A-Za-z0-9_-]+", "[REDACTED]", detail)
    detail = re.sub(r"(?i)Bearer\s+\S+", "Bearer [REDACTED]", detail)
    request_id = exc.headers.get("x-request-id", "") if exc.headers else ""
    suffix = f": {detail[:600]}" if detail else ""
    if request_id:
        suffix += f" (request id: {request_id[:120]})"
    return f"HTTP {exc.code} {exc.reason}{suffix}"


def main() -> int:
    key = getpass.getpass("Enter GROQ_API_KEY (hidden, not saved): ").strip()
    if not key:
        print("No key entered; no request was made.", file=sys.stderr)
        return 2

    request = urllib.request.Request(
        MODELS_URL,
        headers={"Authorization": f"Bearer {key}", "Accept": "application/json"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=15.0) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"Groq rejected the models-list request: {_safe_provider_error(exc, key)}")
        return 1
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        print(f"Could not complete the models-list check: {type(exc).__name__}")
        return 1

    rows = payload.get("data", []) if isinstance(payload, dict) else []
    ids = {row.get("id") for row in rows if isinstance(row, dict) and isinstance(row.get("id"), str)}
    print(f"Groq models-list request: HTTP {response.status}")
    print(f"Models returned: {len(ids)}")
    if MODEL_ID in ids:
        print(f"{MODEL_ID}: listed for this key/account.")
    else:
        print(f"{MODEL_ID}: not listed for this key/account.")
    print("This check lists models only; it does not generate a completion.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
