#!/usr/bin/env python3
"""Refresh the outer LF checksum manifest and create a verified review ZIP."""

from __future__ import annotations

import hashlib
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "SHA256SUMS.txt"
ARCHIVE = ROOT.parent / f"{ROOT.name}_FINAL.zip"


def _payload_files() -> list[Path]:
    files = sorted(
        path
        for path in ROOT.rglob("*")
        if path.is_file()
        and path != MANIFEST
        and "__pycache__" not in path.parts
        and path.suffix != ".pyc"
    )
    if any(path.is_symlink() for path in files):
        raise RuntimeError("Refusing to package a symbolic link")
    return files


def main() -> int:
    files = _payload_files()
    manifest_lines = [
        f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(ROOT).as_posix()}"
        for path in files
    ]
    MANIFEST.write_bytes(("\n".join(manifest_lines) + "\n").encode("utf-8"))

    bundle_files = sorted(
        path
        for path in ROOT.rglob("*")
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"
    )
    with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in bundle_files:
            member = f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}"
            output.write(path, member)

    manifest_member = f"{ROOT.name}/SHA256SUMS.txt"
    with zipfile.ZipFile(ARCHIVE, "r") as package:
        damaged = package.testzip()
        if damaged is not None:
            raise RuntimeError(f"ZIP CRC check failed at {damaged}")
        manifest_text = package.read(manifest_member).decode("utf-8")
        expected: set[str] = set()
        for line in manifest_text.splitlines():
            digest, relative = line.split("  ", 1)
            member = f"{ROOT.name}/{relative}"
            data = package.read(member)
            if hashlib.sha256(data).hexdigest() != digest:
                raise RuntimeError(f"SHA-256 verification failed for {relative}")
            expected.add(member)
        actual = set(package.namelist()) - {manifest_member}
        if actual != expected:
            missing = sorted(expected - actual)
            extra = sorted(actual - expected)
            raise RuntimeError(f"Manifest/archive mismatch; missing={missing}, extra={extra}")

    print(f"Created and verified: {ARCHIVE}")
    print(f"Files listed in SHA256SUMS.txt: {len(files)}")
    print(f"ZIP bytes: {ARCHIVE.stat().st_size}")
    print(f"ZIP SHA-256: {hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
