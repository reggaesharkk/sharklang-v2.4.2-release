# SharkLang v2.4.2 Final Review Bundle

This bundle contains the v2.4.2 security follow-up, its verification logs, and the source artifacts needed to review the changes.

## Contents

- release/ — complete release tree and its LF-only SHA256SUMS.txt.
- review_inputs/SHARKLANG_V24_original.zip — original v2.4 baseline.
- review_inputs/files_6_hardening_source_bundle.zip and hardening.patch — supplied hardening inputs.
- review_inputs/lean_header_fix.patch and windows_utf8_lean_output.patch — certificate reproducibility fixes.
- review_inputs/sign_crlf_hash_fix.patch — raw-byte CLI signing fix, with LF patch endings.
- review_inputs/v24_2_witness_frame_fix.patch — v2.4.2 Witness framing and generic-error changes.
- review_inputs/sharklang_v24_1_pre_v24_2.py — source snapshot immediately before the v2.4.2 changes.
- Earlier v2.4.1 source snapshots for comparing the certificate and CRLF signing fixes.
- SHA256SUMS.txt — checksums for every review-bundle file other than this manifest.

## Review notes

The v2.4.2 change removes the unframed JSON compatibility path from the Witness network parser. Internal processing failures return a generic denial reason. The existing signed example, bytecode, and Lean certificate remain byte-identical.

The v2.4.1 Windows test-key folders and Ubuntu witness vaults were secured locally after review. No private keys, raw shell histories, user names, or local run transcripts are included in this bundle.

## Verification

The release logs record Windows ARM64 tests on Python 3.12.10/OpenSSL 3.0.16 and Ubuntu aarch64 tests on Python 3.14.4/OpenSSL 3.5.5. Each ran under -B, -O -B, and -OO -B. Windows ran 70 tests with 69 passing and one POSIX-only skip; Ubuntu passed all 70. The six-scenario Egress self-test passed on both systems. The Lean compiler log records Lean 4.35.0 targeting x86_64-w64-windows-gnu, separate from the Windows ARM64 Python test environment.

The example bytecode hash is 49eb4fe401077bc9ff4fe2b0110e878bcd22ff1aa5db7653927035c0182e9c49. The Lean certificate hash is da5c7a42f92fbc0f9e57287cd89ca52ab0e1f6930fc96bfcfd2f0b7d78a4bf6a and matches the signed package binding. The example signature verifies.

The bundle manifests cover all release files and review inputs and use LF endings.

## Run live checks on Windows and Ubuntu WSL

This archive already contains the release, test logs, review inputs, and live validation helper. Extract it once, then run from the extracted package root.

In PowerShell:

```powershell
$work = Join-Path $env:USERPROFILE 'Downloads\SHARKLANG_GOVERNED_AI_REVIEW_RELEASE_20261031'
Set-Location $work
python .\tools\live_validate.py
```

In Ubuntu WSL, use the same extracted folder:

```bash
win_profile="$(cmd.exe /c 'echo %USERPROFILE%' | tr -d '\r')"
work="$(wslpath -u "${win_profile}\\Downloads\\SHARKLANG_GOVERNED_AI_REVIEW_RELEASE_20261031")"
cd "$work"
python3 tools/live_validate.py
```

Each run executes the three optimization-mode test suites, the Egress self-test, and the bytecode, Lean certificate, and signature checks. It refreshes the platform-specific logs and both checksum manifests, then writes a timestamped ZIP beside the extracted folder. A failed run exits with code 1 and keeps failure details in the logs. The helper redacts bundle and home-folder paths from test output. Run Ubuntu second if you want one refreshed archive with both platforms' latest logs.

To rebuild the final review ZIP and outer checksum manifest after editing bundle files, run `python .\tools\build_review_zip.py` from the bundle root. This packages the current files and verifies every listed SHA-256 digest and ZIP CRC; it does not rerun the release test suites.

## Governed AI demo

The `governed_ai_demo/` directory contains a runnable, optional demo using the v2.4.2 runtime. It supports Gemini, Groq, Together AI, and OpenRouter. The provider demo is separate from the release test evidence above. Omit `--model` to use the bundled default for the selected provider. Its Together adapter uses the current `api.together.ai` endpoint and a SharkLang User-Agent; this adapter-only update does not change the canonical release test tree. API keys are requested with hidden input and are held only in that process. `PROVIDER_LIVE_RESULTS.md` records screenshot-confirmed Gemini and Together HTTP 200 responses and user-confirmed successful OpenRouter and Groq calls. The live AI requests are real; the purchase amount and limit are simulated policy inputs, and the demo does not process payments.

## Rights and access

This release is published for inspection and private evaluation under the custom `EVALUATION_LICENSE.txt`. It permits people to review the source, run the included tests and demo, and make private evaluation changes. It does not permit production or real-world deployment, commercial use, product or service integration, or redistribution; those require separate written permission or a paid license from the copyright holder. See `RIGHTS_RESERVED.txt` for a short summary.

The planned public GitHub repository is <https://github.com/reggaesharkk/sharklang-v2.4.2-release>. Public visibility lets people view and download the release. It does not grant the broader rights reserved by the evaluation license. The Zenodo record will provide a citable archive and will link back to the repository. Zenodo's record metadata is public.

These notices do not change the separate terms of third-party material or dependencies.
