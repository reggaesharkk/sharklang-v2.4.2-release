#!/usr/bin/env python3
"""SharkPKI v2.4.2: Separated mTLS Transport Certificates (with RFC 5280 SKI/AKI) & Ed25519 Identities."""
from __future__ import annotations

import argparse
from pathlib import Path
from sharklang import SharkPKI


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate SharkPKI v2.4.2 mTLS certs and Ed25519 keys")
    parser.add_argument("pos_dir", nargs="?", default=None, help="Optional positional output directory")
    parser.add_argument("--out-dir", default=".", help="Output directory for generated keys and certs")
    parser.add_argument("--ip", default="127.0.0.1", help="SAN IPv4 address for mTLS leaf certs")
    args = parser.parse_args()

    target_dir = Path(args.pos_dir if args.pos_dir is not None else args.out_dir)
    paths = SharkPKI.generate_all(target_dir, san_ip=args.ip)
    for label, path in sorted(paths.items()):
        print(f"[+] Generated {label}: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
