#!/usr/bin/env python3
"""Run the v2.4.2 live checks for the current OS and create a review ZIP."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import ssl
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path


BUNDLE_ROOT = Path(__file__).resolve().parents[1]
RELEASE = BUNDLE_ROOT / "release"
LOGS = RELEASE / "logs"


def _platform_tag() -> str:
    if os.name == "nt":
        return "windows"
    if platform.system() == "Linux":
        return "ubuntu"
    return platform.system().lower()


def _runtime_info() -> str:
    return f"Python {platform.python_version()} {platform.machine()}; {ssl.OPENSSL_VERSION}"


def _write_text(path: Path, text: str) -> None:
    path.write_bytes(text.replace("\r\n", "\n").replace("\r", "\n").encode("utf-8"))


def _private_path_redacted(text: str) -> str:
    paths = (str(BUNDLE_ROOT), str(RELEASE), str(Path.home()))
    for path in sorted(paths, key=len, reverse=True):
        text = text.replace(path, "<BUNDLE>")
    return text


def _run_logged(name: str, args: list[str], env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        [sys.executable, *args],
        cwd=RELEASE,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    command = "python " + " ".join(args)
    header = (
        f"Platform: {platform.system()} {platform.machine()}\n"
        f"Runtime: {_runtime_info()}\n"
        f"Command: {command}\n\n"
    )
    safe_output = _private_path_redacted(completed.stdout)
    _write_text(LOGS / name, header + safe_output)
    tail = "\n".join(safe_output.splitlines()[-4:])
    print(f"{name}: exit {completed.returncode}")
    if tail:
        print(tail)
    if completed.returncode:
        raise RuntimeError(f"{name} failed; see release/logs/{name}")
    return completed


def _run_capture(args: list[str], env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, *args],
        cwd=RELEASE,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _check_artifacts(env: dict[str, str], temp_dir: Path, tag: str) -> None:
    example = Path("examples/lifecycle_4d_full_stack.shk")
    shipped_bytecode = RELEASE / "examples/lifecycle_4d_full_stack.shkbc"
    shipped_lean = RELEASE / "Lifecycle4DCert.lean"
    signed_package_path = RELEASE / "examples/lifecycle_4d_full_stack.signed.v2.json"
    rebuilt_bytecode = temp_dir / "rebuilt.shkbc"
    rebuilt_lean = temp_dir / "rebuilt_Lifecycle4DCert.lean"
    checks: list[str] = [f"Platform: {platform.system()} {platform.machine()}", f"Runtime: {_runtime_info()}"]

    result = _run_capture(["-B", "sharklang.py", "compile", str(example), "-o", str(rebuilt_bytecode)], env)
    if result.returncode:
        raise RuntimeError("Example bytecode compilation failed: " + result.stdout[-1200:])
    bytecode_match = rebuilt_bytecode.read_bytes() == shipped_bytecode.read_bytes()
    checks.extend(
        [
            "Bytecode: " + ("MATCH" if bytecode_match else "MISMATCH"),
            "Bytecode SHA-256: " + _sha256(rebuilt_bytecode),
            "Shipped bytecode SHA-256: " + _sha256(shipped_bytecode),
        ]
    )
    if not bytecode_match:
        raise RuntimeError("Rebuilt bytecode differs from the shipped bytecode")

    result = _run_capture(
        ["-B", "sharklang.py", "emit-lean", str(example), "-o", str(rebuilt_lean), "--module-name", "Lifecycle4DCert"],
        env,
    )
    if result.returncode:
        raise RuntimeError("Lean certificate regeneration failed: " + result.stdout[-1200:])
    package = json.loads(signed_package_path.read_text(encoding="utf-8"))
    lean_hash = _sha256(rebuilt_lean)
    lean_match = (
        rebuilt_lean.read_bytes() == shipped_lean.read_bytes()
        and lean_hash == package.get("lean_certificate_sha256")
    )
    checks.extend(
        [
            "Lean certificate: " + ("MATCH" if lean_match else "MISMATCH"),
            "Lean certificate SHA-256: " + lean_hash,
            "Signed package Lean SHA-256: " + str(package.get("lean_certificate_sha256")),
        ]
    )
    if not lean_match:
        raise RuntimeError("Regenerated Lean certificate differs from its shipped or signed hash")

    result = _run_capture(
        [
            "-B",
            "sharklang.py",
            "verify",
            str(signed_package_path),
            "--pubkey-hex",
            str(package["signer_pubkey_hex"]),
            "--key-id",
            str(package["key_id"]),
        ],
        env,
    )
    if result.returncode:
        raise RuntimeError("Signed example verification failed: " + result.stdout[-1200:])
    verify_result = json.loads(result.stdout)
    if verify_result.get("status") != "VERIFIED":
        raise RuntimeError("Signed example did not report VERIFIED")
    checks.append("Signed example: VERIFIED against the public key embedded in the package")

    lean = shutil.which("lean")
    if lean:
        version = subprocess.run(
            [lean, "+v4.35.0", "--version"],
            cwd=RELEASE,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        compile_result = subprocess.run(
            [lean, "+v4.35.0", "Lifecycle4DCert.lean"],
            cwd=RELEASE,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        if version.returncode or compile_result.returncode:
            raise RuntimeError("Lean 4.35.0 compilation failed: " + compile_result.stdout[-1200:])
        checks.extend(["Lean version: " + version.stdout.strip(), "Lean certificate compile: PASS"])
    else:
        checks.append("Lean compiler: not found on PATH; see the carried-forward lean_check.log")

    _write_text(LOGS / f"live_artifact_checks_{tag}.log", "\n".join(checks) + "\n")
    print(f"live_artifact_checks_{tag}.log: all available artifact checks passed")


def _write_manifest(base: Path) -> None:
    manifest = base / "SHA256SUMS.txt"
    rows = []
    for path in sorted(base.rglob("*")):
        if not path.is_file() or path == manifest:
            continue
        relative = path.relative_to(base).as_posix()
        rows.append(f"{_sha256(path)}  {relative}")
    _write_text(manifest, "\n".join(rows) + "\n")


def _verify_manifest(base: Path) -> None:
    manifest = base / "SHA256SUMS.txt"
    for line in manifest.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        path = base / relative
        if not path.is_file() or _sha256(path) != expected:
            raise RuntimeError(f"Manifest verification failed: {relative}")


def main() -> int:
    if not RELEASE.is_dir() or not (RELEASE / "sharklang.py").is_file():
        raise SystemExit("Run this script from the extracted v2.4.2 review bundle.")
    LOGS.mkdir(parents=True, exist_ok=True)
    tag = _platform_tag()
    env = os.environ.copy()
    failures: list[str] = []
    temp_context = None
    if os.name == "nt":
        temp_context = tempfile.TemporaryDirectory(prefix="sharklang_live_tmp_", dir=BUNDLE_ROOT)
        env["TEMP"] = temp_context.name
        env["TMP"] = temp_context.name

    try:
        for suffix, args in (
            ("O0", ["-B", "sharklang.py"]),
            ("O1", ["-O", "-B", "sharklang.py"]),
            ("O2", ["-OO", "-B", "sharklang.py"]),
        ):
            try:
                _run_logged(f"live_{tag}_test_{suffix}.log", args, env)
            except Exception as exc:
                failure = _private_path_redacted(str(exc))
                failures.append(failure)
                print(f"FAILED: {failure}")
        try:
            _run_logged(f"live_{tag}_egress_self_test.log", ["-B", "shark_egress.py", "--self-test"], env)
        except Exception as exc:
            failure = _private_path_redacted(str(exc))
            failures.append(failure)
            print(f"FAILED: {failure}")
        with tempfile.TemporaryDirectory(prefix="sharklang_artifacts_", dir=BUNDLE_ROOT) as temp:
            try:
                _check_artifacts(env, Path(temp), tag)
            except Exception as exc:
                failure = _private_path_redacted(str(exc))
                failures.append(failure)
                _write_text(LOGS / f"live_artifact_checks_{tag}.log", f"FAILED: {failure}\n")
                print(f"FAILED: {failure}")
    finally:
        if temp_context is not None:
            temp_context.cleanup()

    failure_log = LOGS / f"live_{tag}_failures.log"
    if failures:
        _write_text(failure_log, "\n".join(failures) + "\n")
    elif failure_log.exists():
        failure_log.unlink()

    _write_manifest(RELEASE)
    _verify_manifest(RELEASE)
    _write_manifest(BUNDLE_ROOT)
    _verify_manifest(BUNDLE_ROOT)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_zip = BUNDLE_ROOT.parent / f"SHARKLANG_V24_2_LIVE_REVIEW_{tag.upper()}_{timestamp}.zip"
    with zipfile.ZipFile(output_zip, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(BUNDLE_ROOT.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(BUNDLE_ROOT).as_posix())
    with zipfile.ZipFile(output_zip, "r") as archive:
        if archive.testzip() is not None:
            raise RuntimeError("The live review ZIP failed its CRC check")
    print(f"Final review ZIP: {output_zip}")
    print(f"ZIP SHA-256: {_sha256(output_zip)}")
    if failures:
        print("Checks failed; the ZIP includes the failure logs.")
        return 1
    print("All live checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
