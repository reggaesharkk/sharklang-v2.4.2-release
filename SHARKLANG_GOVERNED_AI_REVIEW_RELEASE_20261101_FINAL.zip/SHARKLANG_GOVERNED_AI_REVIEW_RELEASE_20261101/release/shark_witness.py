#!/usr/bin/env python3
"""SharkWitness v2.4.2: External Trusted Observer with 4-Byte Framed mTLS, Hex Validation & SQLite Ledger."""
from __future__ import annotations

import argparse
from pathlib import Path
import socket
import ssl
from sharklang import SharkWitnessServer, _recv_framed_json, _send_framed_json


def run_server(pki_dir: Path, host: str = "127.0.0.1", port: int = 8888) -> None:
    witness = SharkWitnessServer(pki_dir, bind_host=host, bind_port=port)
    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    context.minimum_version = ssl.TLSVersion.TLSv1_3
    if hasattr(ssl, "VERIFY_X509_STRICT"):
        context.verify_flags |= ssl.VERIFY_X509_STRICT
    context.load_cert_chain(
        certfile=str(pki_dir / "witness_tls.pem"),
        keyfile=str(pki_dir / "witness_tls.key"),
    )
    context.load_verify_locations(cafile=str(pki_dir / "ca.pem"))
    context.verify_mode = ssl.CERT_REQUIRED

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((host, port))
    server.listen(8)
    print(f"[*] SharkWitness v2.4.2 ACTIVE on ({host!r}, {port}). Waiting for Governor...")

    while True:
        try:
            client, _ = server.accept()
            with context.wrap_socket(client, server_side=True) as ssock:
                req = _recv_framed_json(ssock)
                print(f"\n[?] Validating Epoch {req.get('epoch')} (state_hash={str(req.get('state_hash', ''))[:16]}...)...")
                resp = witness.process_request(req)
                print(f"    -> Status: {resp.get('status')}")
                _send_framed_json(ssock, resp)
        except KeyboardInterrupt:
            break
        except Exception as exc:
            print(f"[!] Error: {exc}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run SharkWitness v2.4.2 mTLS Trusted Observer")
    parser.add_argument("pos_dir", nargs="?", default=None, help="Optional positional PKI directory")
    parser.add_argument("pos_port", nargs="?", type=int, default=None, help="Optional positional TCP port")
    parser.add_argument("--pki-dir", default=".", help="Directory containing PKI certs and keys")
    parser.add_argument("--host", default="127.0.0.1", help="Bind host")
    parser.add_argument("--port", type=int, default=8888, help="Bind port")
    args = parser.parse_args()
    pki = Path(args.pos_dir if args.pos_dir is not None else args.pki_dir)
    port_num = args.pos_port if args.pos_port is not None else args.port
    run_server(pki, host=args.host, port=port_num)
