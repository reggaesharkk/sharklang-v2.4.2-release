#!/usr/bin/env python3
"""SharkEgress v2.4.2: Enforced Governor Client ("Two-Man Rule") with 6-Scenario Self-Test & Optional Multi-LLM API Gate."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import tempfile
from sharklang import SharkEgressClient, SharkPKI, SharkWitnessServer


def run_self_verification(pki_dir: Path, port: int) -> int:
    egress = SharkEgressClient(pki_dir, port=port)

    print("--- Test 1: Valid First Request (Epoch 100) ---")
    ok1, msg1, rec1 = egress.request_egress(100, "gamma=1.0, psi=0.5")
    print(f"Result: {msg1} (state_hash={rec1.get('state_hash', 'N/A')[:16]}..., chain_hash={rec1.get('chain_hash', 'N/A')[:16]}...)")
    if not ok1:
        return 1

    print("\n--- Test 2: Replay Attack on Epoch 100 (Must Fail Closed) ---")
    ok2, msg2, _ = egress.request_egress(100, "gamma=1.0, psi=0.5")
    print(f"Result: {msg2}")
    if ok2:
        return 1

    print("\n--- Test 3: Equivocation Attack on Epoch 100 (Must Fail Closed) ---")
    ok3, msg3, _ = egress.request_egress(
        100, "gamma=999.0, psi=0.5", allow_idempotent_retry=True
    )
    print(f"Result: {msg3}")
    if ok3:
        return 1

    print("\n--- Test 4: Idempotent Retry Recovery on Epoch 100 (Must Succeed) ---")
    ok4, msg4, rec4 = egress.request_egress(
        100, "gamma=1.0, psi=0.5", allow_idempotent_retry=True
    )
    print(f"Result: {msg4} (idempotent_replay={rec4.get('idempotent_replay')})")
    if not ok4 or not rec4.get("idempotent_replay"):
        return 1

    print("\n--- Test 5: Valid Next Epoch (Epoch 101) ---")
    ok5, msg5, rec5 = egress.request_egress(101, "gamma=1.05, psi=0.51")
    print(f"Result: {msg5} (state_hash={rec5.get('state_hash', 'N/A')[:16]}..., chain_hash={rec5.get('chain_hash', 'N/A')[:16]}...)")
    if not ok5:
        return 1

    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run SharkEgress v2.4.2 Governor Client")
    parser.add_argument("pos_dir", nargs="?", default=None, help="Optional positional PKI directory")
    parser.add_argument("pos_port", nargs="?", type=int, default=None, help="Optional positional TCP port")
    parser.add_argument("--pki-dir", default=".", help="Directory containing PKI certs and keys")
    parser.add_argument("--port", type=int, default=8888, help="Witness mTLS TCP port")
    parser.add_argument("--provider", choices=["gemini", "groq", "together", "openrouter"], default=None, help="Optional Witness-gated API provider")
    parser.add_argument("--epoch", type=int, default=200, help="Epoch ID for Witness-gated API call")
    parser.add_argument("--prompt", default="Report governed system status.", help="Prompt for Witness-gated API call")
    parser.add_argument("--live", action="store_true", help="Dispatch live HTTPS call after Witness SEALED receipt (requires provider env var)")
    parser.add_argument(
        "--self-test",
        action="store_true",
        help="Generate temporary PKI, start background Witness, and verify all 6 scenarios",
    )
    args = parser.parse_args()

    if args.self_test:
        exit_code = 1
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            tmp_dir = Path(tmp)
            SharkPKI.generate_all(tmp_dir)
            srv = SharkWitnessServer(tmp_dir, bind_port=0)
            ephemeral_port = srv.start_background()
            try:
                rc = run_self_verification(tmp_dir, ephemeral_port)
            finally:
                srv.stop()
            print("\n--- Test 6: Witness Offline Crash Test (Must Fail Closed) ---")
            egress_dead = SharkEgressClient(tmp_dir, port=ephemeral_port)
            ok6, msg6, _ = egress_dead.request_egress(102, "gamma=1.10, psi=0.52")
            print(f"Result: {msg6}")
            exit_code = 0 if (rc == 0 and not ok6) else 1
        raise SystemExit(exit_code)

    pki = Path(args.pos_dir if args.pos_dir is not None else args.pki_dir)
    port_num = args.pos_port if args.pos_port is not None else args.port
    if args.provider:
        client = SharkEgressClient(pki, port=port_num)
        res = client.execute_governed_api_call(
            args.epoch, args.provider, args.prompt, dry_run=not args.live
        )
        print(json.dumps(res, indent=2, sort_keys=True))
        raise SystemExit(0)
    raise SystemExit(run_self_verification(pki, port_num))
