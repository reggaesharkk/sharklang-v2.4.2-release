# SharkLang Governed AI Demo

This is a small, non-production demo of SharkLang governing an AI request. It evaluates a simulated purchase amount against a spending cap in SharkLang. If the policy denies the request, the demo stops before contacting the Witness or an AI provider. If approved, a local mTLS Witness signs the exact request state and bytecode hash before egress is opened.

The demo does not purchase anything or control real funds. The Witness and temporary keys run on the same computer and are deleted at exit; this demonstrates the flow, not an independent production approval service.

## Requirements

- Python 3.10 or newer
- The `cryptography` package

The folder includes the v2.4.2 `sharklang.py` runtime used for this demo.

## Open the included demo

The demo is included in this release archive under `governed_ai_demo/`; no separate demo ZIP is needed. After extracting the release archive, open this folder.

In PowerShell:

```powershell
$demo = Join-Path $env:USERPROFILE 'Downloads\SHARKLANG_GOVERNED_AI_REVIEW_RELEASE_20261101\governed_ai_demo'
Set-Location $demo
```

In Ubuntu WSL, use the same extracted folder:

```bash
win_profile="$(cmd.exe /c 'echo %USERPROFILE%' | tr -d '\r')"
demo="$(wslpath -u "${win_profile}\\Downloads\\SHARKLANG_GOVERNED_AI_REVIEW_RELEASE_20261101\\governed_ai_demo")"
cd "$demo"
```

## Try the policy without an AI API call

From this folder, run:

```powershell
python .\governed_ai_demo.py --amount 12.50 --limit 20.00
```

This compiles and runs the SharkLang policy, starts a temporary local Witness, and prints a signed `AUTHORIZED_DRY_RUN` receipt. It makes no request to a provider and needs no API key.

Try a denied request:

```powershell
python .\governed_ai_demo.py --amount 25.00 --limit 20.00
```

The result should say `DENIED`; no Witness request and no provider request are made.

## Optional live provider request

The current runtime supports Gemini, Groq, Together, and OpenRouter. The default model IDs are `gemini-3.5-flash-lite`, `openai/gpt-oss-20b`, `Prism-ML/Ternary-Bonsai-27B`, and `openrouter/free`, respectively. Provider catalogs and account access change over time, so treat these as current starting points rather than permanent guarantees.

To try OpenRouter's default model route after approval:

```powershell
python .\governed_ai_demo.py --provider openrouter --live
```

Each API key is read from that provider's environment variable; if it is not set, the script prompts with hidden input. The key is kept only in the running process and is not printed, written to a file, or sent to another provider. Do not paste a key into chat or into the prompt.

For Groq, the active model `openai/gpt-oss-20b` is listed in [Groq's supported models](https://console.groq.com/docs/models) and as a replacement for retired Llama defaults in [Groq's deprecation guide](https://console.groq.com/docs/deprecations). Groq currently lists token pricing for Developer-tier use; a free account may instead be rate-limited or lack access to a particular model. Confirm the tier shown in your Groq console before the request. This one demo request uses a short prompt, but it is still a live provider call.

For Together AI, `Prism-ML/Ternary-Bonsai-27B` is listed as a free serverless chat model in [Together's current model catalog](https://docs.together.ai/docs/serverless/models). If your account does not expose it, the request will fail before returning an answer; do not substitute a paid model unless you choose to.

The Together adapter sends requests to `https://api.together.ai/v1/chat/completions` and identifies itself with a SharkLang User-Agent. This replaces the previous legacy `.xyz` host and the generic Python `urllib` User-Agent.

Run one live provider request at a time so you can inspect the result. Leave out `--model`, `--amount`, and `--limit` to use the demo's configured defaults:

```powershell
python .\governed_ai_demo.py --provider groq --live
python .\governed_ai_demo.py --provider together --live
```

In Ubuntu, use `python3` and the same arguments. The demo appends the amount and cap to the provider prompt and displays only the final answer plus basic usage fields; provider-specific reasoning metadata is filtered. Use a non-sensitive prompt because `--live` sends it to the chosen provider. If policy denies the amount, no provider call is made even when `--live` is present.

If a provider rejects a request, the demo prints only the structured error code/type/message and redacts known API-key formats. A 401 usually means the key is missing, invalid, or for another provider. A 403 can mean the account or model lacks access. Cloudflare error 1010 indicates an edge/client-signature block; changing API keys or model selection will not clear a provider-side block, so stop retrying and contact that provider.

To check Groq access without generating an answer, run `python .\check_groq_key.py` from this folder. It prompts for the key with hidden input and sends only a GET request to Groq's models-list endpoint; it does not send a chat prompt. It reports whether `openai/gpt-oss-20b` appears for that key/account.

## What the demo shows

- SharkLang's compiled policy decides whether the simulated request is within its cap.
- The policy's bytecode hash is included in the governed request state.
- A local Witness must return a valid signed receipt before provider egress.
- Replay protection and the offline fail-closed behavior are covered by the v2.4.2 suite.

This is a learning/demo artifact, not a complete financial control or independent security audit.

## Rights

SharkLang and the accompanying demo are available for private, non-commercial review and evaluation under the package-level `EVALUATION_LICENSE.txt`. You may run the tests and demo in a non-production setting and make private evaluation changes. Production or real-world deployment, commercial use, product or service integration, and redistribution require separate written permission or a paid license. Separately installed dependencies and third-party material remain subject to their own terms.
