#!/usr/bin/env python3
"""Sandboxed SharkLang purchase-policy and witness-gated AI demo."""

from __future__ import annotations

import argparse
from decimal import Decimal, InvalidOperation
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import urllib.error

from sharklang import BytecodeCompiler, SharkEgressClient, SharkPKI, SharkVM, SharkWitnessServer


PROVIDERS = {
    "gemini": "GEMINI_API_KEY",
    "groq": "GROQ_API_KEY",
    "together": "TOGETHER_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}
DEFAULT_MODELS = {
    "gemini": "gemini-3.5-flash-lite",
    "groq": "openai/gpt-oss-20b",
    "together": "Prism-ML/Ternary-Bonsai-27B",
    "openrouter": "openrouter/free",
}
MAX_AMOUNT = Decimal("10000.00")


def _money_arg(raw: str) -> Decimal:
    try:
        value = Decimal(raw)
    except InvalidOperation as exc:
        raise argparse.ArgumentTypeError("enter a dollar amount, such as 12.50") from exc
    if not value.is_finite() or value < 0 or value > MAX_AMOUNT:
        raise argparse.ArgumentTypeError("amount must be between 0 and 10000")
    if value.as_tuple().exponent < -2:
        raise argparse.ArgumentTypeError("use at most two decimal places")
    return value


def _shark_number(value: Decimal) -> str:
    rendered = format(value, "f")
    return rendered if "." in rendered else rendered + ".0"


def _policy_source(amount: Decimal, limit: Decimal) -> str:
    template_path = Path(__file__).with_name("purchase_policy.shk")
    template = template_path.read_text(encoding="utf-8")
    source = template.replace("__AMOUNT__", _shark_number(amount))
    source = source.replace("__LIMIT__", _shark_number(limit))
    if "__AMOUNT__" in source or "__LIMIT__" in source:
        raise RuntimeError("Policy template contains an unfilled value")
    return source


def _display_egress_result(result: dict[str, object]) -> dict[str, object]:
    """Print only the user-facing answer and minimal usage; drop provider reasoning metadata."""
    safe = {key: value for key, value in result.items() if key != "response"}
    response = result.get("response")
    if not isinstance(response, dict):
        return safe

    choices = response.get("choices")
    first_choice = choices[0] if isinstance(choices, list) and choices else {}
    message = first_choice.get("message", {}) if isinstance(first_choice, dict) else {}
    usage = response.get("usage", {})
    safe_response: dict[str, object] = {}
    for field in ("model", "provider"):
        value = response.get(field)
        if value is not None:
            safe_response[field] = value
    if isinstance(first_choice, dict) and first_choice.get("finish_reason") is not None:
        safe_response["finish_reason"] = first_choice["finish_reason"]
    if isinstance(message, dict) and message.get("content") is not None:
        safe_response["answer"] = message["content"]
    if isinstance(usage, dict):
        safe_usage = {
            field: usage[field]
            for field in ("prompt_tokens", "completion_tokens", "total_tokens", "cost")
            if field in usage
        }
        if safe_usage:
            safe_response["usage"] = safe_usage
    safe["response_summary"] = safe_response
    return safe


def _safe_error_text(exc: Exception) -> str:
    """Show a provider's structured rejection reason without exposing credentials."""
    if not isinstance(exc, urllib.error.HTTPError):
        return f"{type(exc).__name__}: {exc}"

    detail = ""
    try:
        raw = exc.read(8192).decode("utf-8", errors="replace")
        payload = json.loads(raw)
        error = payload.get("error") if isinstance(payload, dict) else None
        if isinstance(error, dict):
            fields = [error.get("code"), error.get("type"), error.get("message"), error.get("detail")]
            detail = " | ".join(str(value) for value in fields if isinstance(value, str) and value)
        if not detail:
            detail = json.dumps(payload, ensure_ascii=True)
    except json.JSONDecodeError:
        detail = raw
    except (OSError, UnicodeError):
        detail = "Provider did not return a readable error body."

    # Redact known provider-key formats in case an upstream error ever echoes input.
    for env_var in PROVIDERS.values():
        secret = os.environ.get(env_var, "")
        if secret:
            detail = detail.replace(secret, "[REDACTED]")
    for pattern in (
        r"(?i)\b(?:Bearer\s+)?gsk_[A-Za-z0-9_-]+",
        r"(?i)\b(?:Bearer\s+)?sk-or-v1-[A-Za-z0-9_-]+",
        r"(?i)\b(?:Bearer\s+)?tgp_v1_[A-Za-z0-9_-]+",
        r"(?i)\b(?:Bearer\s+)?AIza[A-Za-z0-9_-]+",
        r"(?i)Bearer\s+\S+",
    ):
        detail = re.sub(pattern, "[REDACTED]", detail)
    detail = " ".join(detail.split())[:600]
    suffix = f": {detail}" if detail else ""
    request_id = exc.headers.get("x-request-id", "") if exc.headers else ""
    if request_id:
        suffix += f" (request id: {request_id[:120]})"
    return f"HTTPError: HTTP {exc.code} {exc.reason}{suffix}"


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a simulated budget rule through SharkLang and a local Witness."
    )
    parser.add_argument("--amount", type=_money_arg, default=Decimal("12.50"))
    parser.add_argument("--limit", type=_money_arg, default=Decimal("20.00"))
    parser.add_argument("--provider", choices=sorted(PROVIDERS), default="gemini")
    parser.add_argument(
        "--model",
        default=None,
        help="Optional provider model ID; defaults use the selected models documented in README.md.",
    )
    parser.add_argument(
        "--prompt",
        default="In one short sentence, explain why this simulated purchase is within its approved budget.",
        help="Prompt sent only when --live is selected; do not include private information.",
    )
    parser.add_argument(
        "--live",
        action="store_true",
        help="After policy approval and a signed local Witness receipt, make a billable provider request.",
    )
    return parser


def main() -> int:
    args = _parser().parse_args()
    source = _policy_source(args.amount, args.limit)
    bytecode = BytecodeCompiler.compile(source)
    execution = SharkVM(max_steps=100).run(bytecode)
    approved = execution.outputs.get("policy_approved") == 1
    bytecode_sha256 = hashlib.sha256(bytecode.to_canonical_bytes()).hexdigest()

    summary: dict[str, object] = {
        "demo": "simulated_purchase_budget",
        "requested_amount": f"{args.amount:.2f}",
        "spending_limit": f"{args.limit:.2f}",
        "policy": "APPROVED" if approved else "DENIED",
        "bytecode_sha256": bytecode_sha256,
        "provider": args.provider,
        "live_request": False,
    }

    if not approved:
        summary["result"] = "No Witness request or provider request was made."
        print(json.dumps(summary, indent=2, sort_keys=True))
        return 0

    env_var = PROVIDERS[args.provider]
    if args.live and not os.environ.get(env_var, "").strip():
        secret = getpass.getpass(f"Enter {env_var} (input hidden; not saved): ").strip()
        if not secret:
            print("No key entered; stopping before contacting the Witness or provider.", file=sys.stderr)
            return 2
        os.environ[env_var] = secret

    governor_state = {
        "demo_policy": "purchase_cap_v1",
        "requested_amount": f"{args.amount:.2f}",
        "spending_limit": f"{args.limit:.2f}",
        "policy_approved": True,
    }
    provider_prompt = (
        f"{args.prompt.strip()}\n"
        f"Simulated purchase amount: ${args.amount:.2f}. "
        f"Approved spending cap: ${args.limit:.2f}."
    )

    # The temporary PKI and Witness are local to this demo run. The provider is
    # contacted only when --live is set and the compiled SharkLang policy approves.
    with tempfile.TemporaryDirectory(prefix="sharklang_governed_demo_") as temp_dir:
        pki_dir = Path(temp_dir)
        SharkPKI.generate_all(pki_dir)
        witness = SharkWitnessServer(pki_dir, bind_port=0)
        port = witness.start_background()
        try:
            client = SharkEgressClient(pki_dir, port=port)
            result = client.execute_governed_api_call(
                1,
                args.provider,
                provider_prompt,
                model=args.model or DEFAULT_MODELS.get(args.provider),
                governor_state=governor_state,
                bytecode_sha256=bytecode_sha256,
                dry_run=not args.live,
            )
        finally:
            witness.stop()

    summary["live_request"] = bool(args.live)
    summary["egress"] = _display_egress_result(result)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"Demo stopped safely: {_safe_error_text(exc)}", file=sys.stderr)
        raise SystemExit(1)
